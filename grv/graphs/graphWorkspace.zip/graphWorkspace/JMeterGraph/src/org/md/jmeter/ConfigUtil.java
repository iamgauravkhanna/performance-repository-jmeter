package org.md.jmeter;

import java.io.InputStream;
import java.util.Properties;

/**
 * Utility to get runtime properties Needs a file named config.properties in the
 * classpath
 * 
 * @author DS
 * 
 */
public class ConfigUtil {
	private static final String JMETER_HOME = "JMETER_HOME";
	private static final String JMETER_PROPERTIES = "JMETER_PROPERTIES";
	private static final String OUTPUT_GRAPH_DIR = "OUTPUT_GRAPH_DIR";

	private static Properties properties = new Properties();
	static {
		load();
	}

	public static String getProperty(String propertyName) {
		return properties.getProperty(propertyName);
	}

	// function as reload as well
	public static synchronized void load() {
		try {
			InputStream is = null;
			is = Thread.currentThread().getContextClassLoader()
					.getResourceAsStream("org/md/jmeter/config.properties");
			properties.load(is);
			if (is != null) {
				is.close();
			}
		} catch (Exception e) {
			// can't throw IOException from static initializer
			throw new RuntimeException(
					"Couldnt load config file org/md/jmeter/config.properties from classpath",
					e);
		}
	}

	public static String getJMeterHome() {
		return getProperty(JMETER_HOME);
	}

	public static String getJMeterProperties() {
		return getJMeterHome() + getProperty(JMETER_PROPERTIES);
	}

	public static String getOutputGraphDir() {
		return getProperty(OUTPUT_GRAPH_DIR);
	}

}
