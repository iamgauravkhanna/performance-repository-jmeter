package org.md.jmeter.graph.visualizer;

import java.io.IOException;
import java.util.Date;
import java.util.Set;
import java.util.TreeSet;
import org.apache.jmeter.samplers.SampleResult;

/**
 * Calculates throughput for a result file. Throughput is calculated as number
 * of request per min v/s threads Threads are counted using the threadname
 * obtained from sampleResult (doesn't account for thread groups) The total time
 * is calculated as time between the greatest endtime of any sample and smallest
 * starttime of any sample Shouldn't be constrained by the size file since we
 * dont keep any proportional item in memory
 * 
 * @author DS
 */
public class TotalThroughputVisualizer extends AbstractOfflineVisualizer {
	private static final long serialVersionUID = 1L;
	private Date minDate = null;
	private Date maxDate = null;
	private long sampleCount = 0;
	private Set<String> threadNames = new TreeSet<String>();

	public void add(SampleResult sampleResult) {
		Date d = new Date(sampleResult.getStartTime());
		Date d2 = new Date(sampleResult.getEndTime());
		if (minDate == null || d.before(minDate)) {
			minDate = d;
		}
		if (maxDate == null || d2.after(maxDate)) {
			maxDate = d2;
		}
		// if you add any decorators, I assume you know what you are doing.
		sampleCount++;
		threadNames.add(sampleResult.getThreadName());

	}

	/**
	 * @return a Throughput object
	 */
	public Object writeOutput() throws IOException {
		double throughput = ((double) sampleCount * (1000 * 60))
				/ (maxDate.getTime() - minDate.getTime()); // requests per
		// minute
		Throughput result = new Throughput(threadNames.size(), throughput);
		return result;
	}

}
