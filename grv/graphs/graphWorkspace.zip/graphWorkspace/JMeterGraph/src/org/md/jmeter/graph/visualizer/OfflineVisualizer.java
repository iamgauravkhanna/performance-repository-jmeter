package org.md.jmeter.graph.visualizer;

import java.io.IOException;

import org.apache.jmeter.visualizers.Visualizer;

/**
 * Interface to add a method to the JMeter interface
 * 
 * @author DS
 */
public interface OfflineVisualizer extends Visualizer {
	// need to rethink this.
	/**
	 * Ugly method. Serves two purposes 1. Usually writes the chart image and
	 * returns nothing 2. Returns a value which is meant to be combined and
	 * writes nothing.
	 * 
	 * @return any thing under the sun, callers should know based on what they
	 *         pass in
	 * @throws IOException
	 */
	public Object writeOutput() throws IOException;
}
