package org.md.jmeter;

import java.io.File;
import java.util.Arrays;

import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.reporters.ResultCollectorHelper;
import org.apache.jmeter.util.JMeterUtils;
import org.md.jmeter.graph.visualizer.AggregateChartVisualizer;
import org.md.jmeter.graph.visualizer.CompositeVisualizer;
import org.md.jmeter.graph.visualizer.LabelFilterVisualizer;
import org.md.jmeter.graph.visualizer.LineChartVisualizer;
import org.md.jmeter.graph.visualizer.MinMaxAvgGraphVisualizer;
import org.md.jmeter.graph.visualizer.OfflineVisualizer;
import org.md.jmeter.graph.visualizer.StackedBarChartVisualizer;

/**
 * Illustrates using the classes to generate the charts
 * 
 * @author DS
 * 
 */
public class GraphClient {
	// this has been specified relative to wherever you are running from
	private static final String JMETER_RESULT_DIR = "sampleResult";
	private static final String JMETER_RESULT_FILE = JMETER_RESULT_DIR
			+ "/OfflineGraphs-dev-200912311310.jtl";

	/**
	 * initialise the properties that the JMeter API's need
	 */
	public static void init() {
		// initialise JMeter
		JMeterUtils.setJMeterHome(ConfigUtil.getJMeterHome());
		JMeterUtils.getProperties(ConfigUtil.getJMeterProperties());
	}
	public static void init(String jmeterHome) {
		// initialise JMeter
		JMeterUtils.setJMeterHome(jmeterHome);
		JMeterUtils.getProperties(jmeterHome + File.separator + "bin/jmeter.properties");
	}
	
	/**
	 * Shows how to use the LineChartVisualizer
	 * 
	 * @throws Exception
	 */
	public static void writeLineChart() throws Exception {
		File f = new File(JMETER_RESULT_FILE);
		ResultCollector rc = new ResultCollector();
		LineChartVisualizer v = new LineChartVisualizer(ConfigUtil
				.getOutputGraphDir()
				+ "/LineChart.png");
		ResultCollectorHelper rch = new ResultCollectorHelper(rc, v);
		XStreamJTLParser p = new XStreamJTLParser(f, rch);
		p.parse();
		v.writeOutput();
	}

	/**
	 * Shows how to use the AggregateChartVisualizer
	 * 
	 * @throws Exception
	 */
	public static void writeAggregateChart() throws Exception {
		writeAggregateChart(JMETER_RESULT_FILE, ConfigUtil.getOutputGraphDir()
				+ "/AggregateChart");
	}

	public static void writeAggregateChart(String resultFile, String prefix) throws Exception {
		File f = new File(resultFile);
		ResultCollector rc = new ResultCollector();
		AggregateChartVisualizer v = new AggregateChartVisualizer(prefix);
		ResultCollectorHelper rch = new ResultCollectorHelper(rc, v);
		XStreamJTLParser p = new XStreamJTLParser(f, rch);
		p.parse();
		v.writeOutput();
	}
	
	public static void writeAggregateChartWithThreshold() throws Exception {
		writeAggregateChartWithThreshold(JMETER_RESULT_FILE,ConfigUtil
				.getOutputGraphDir()
				+ "/AggregateChartThreshold",true,500);
	}	

	//use a template method sometime
	public static void writeAggregateChartWithThreshold(String jmeterResultFile, String prefix, boolean showThreshold, double thresholdValue) throws Exception {
		File f = new File(jmeterResultFile);
		ResultCollector rc = new ResultCollector();
		AggregateChartVisualizer v = new AggregateChartVisualizer(prefix,showThreshold,thresholdValue);
		ResultCollectorHelper rch = new ResultCollectorHelper(rc, v);
		XStreamJTLParser p = new XStreamJTLParser(f, rch);
		p.parse();
		v.writeOutput();
	}
	/**
	 * Shows how to use the LabelFilterVisualizer along with
	 * MinMaxAvgGraphVisualizer to generate the graph for a single label
	 * 
	 * @throws Exception
	 */
	public static void writeFilteredMinMaxAvgChart() throws Exception {
		File f = new File(JMETER_RESULT_FILE);
		ResultCollector rc = new ResultCollector();
		MinMaxAvgGraphVisualizer v = new MinMaxAvgGraphVisualizer(ConfigUtil
				.getOutputGraphDir()
				+ "/MinMaxAvg.png");
		String[] labels = { "Component reference" };
		LabelFilterVisualizer lv = new LabelFilterVisualizer(Arrays
				.asList(labels), v);
		ResultCollectorHelper rch = new ResultCollectorHelper(rc, lv);
		XStreamJTLParser p = new XStreamJTLParser(f, rch);
		p.parse();
		lv.writeOutput();
	}

	/**
	 * Shows how to use the LabelFilterVisualizer along with
	 * StackedBarChartVisualizer to generate the graph for a single label
	 * 
	 * @throws Exception
	 */
	public static void writeFilteredStackedBarChart() throws Exception {
		File f = new File(JMETER_RESULT_FILE);
		ResultCollector rc = new ResultCollector();
		StackedBarChartVisualizer v = new StackedBarChartVisualizer(ConfigUtil
				.getOutputGraphDir()
				+ "/StackedBarChart.png");
		String[] labels = { "Component reference" };
		LabelFilterVisualizer lv = new LabelFilterVisualizer(Arrays
				.asList(labels), v);
		ResultCollectorHelper rch = new ResultCollectorHelper(rc, lv);
		XStreamJTLParser p = new XStreamJTLParser(f, rch);
		p.parse();
		lv.writeOutput();
	}

	/**
	 * Shows how to use the CompositeVisualizer to generate all the multiple
	 * graphs with a single pass of the result file. This would be faster than
	 * calling the API's for each type of graph, but would need more memory
	 * 
	 * @throws Exception
	 */
	public static void writeAllAtOnce() throws Exception {
		File f = new File(JMETER_RESULT_FILE);
		ResultCollector rc = new ResultCollector();
		LineChartVisualizer lcv = new LineChartVisualizer(ConfigUtil
				.getOutputGraphDir()
				+ "/AllLineChart.png");
		StackedBarChartVisualizer sbv = new StackedBarChartVisualizer(
				ConfigUtil.getOutputGraphDir() + "/AllStackedBarChart.png");
		MinMaxAvgGraphVisualizer mmav = new MinMaxAvgGraphVisualizer(ConfigUtil
				.getOutputGraphDir()
				+ "/AllMinMaxAvg.png");
		String[] labels = { "Component reference" };
		LabelFilterVisualizer lv = new LabelFilterVisualizer(Arrays
				.asList(labels), sbv);
		LabelFilterVisualizer lv2 = new LabelFilterVisualizer(Arrays
				.asList(labels), mmav);
		OfflineVisualizer[] vs = { lcv, lv, lv2 };
		CompositeVisualizer cv = new CompositeVisualizer(Arrays.asList(vs));
		ResultCollectorHelper rch = new ResultCollectorHelper(rc, cv);
		XStreamJTLParser p = new XStreamJTLParser(f, rch);
		p.parse();
		cv.writeOutput();
	}

	/**
	 * Shows using the above classes to parse multiple files and creating graphs
	 * that could compare results
	 * 
	 * @throws Exception
	 */
	public static void writeThroughPutChart() throws Exception {
		String[] files = {
				JMETER_RESULT_DIR + "/OfflineGraphs-dev-200912311310.jtl",
				JMETER_RESULT_DIR + "/OfflineGraphs-dev-200912311312.jtl",
				JMETER_RESULT_DIR + "/OfflineGraphs-dev-200912311315.jtl",
				JMETER_RESULT_DIR + "/OfflineGraphs-dev-200912311316.jtl",
				JMETER_RESULT_DIR + "/OfflineGraphs-dev-200912311318.jtl" };
		MultiFileThroughput mft = new MultiFileThroughput(Arrays.asList(files),
				ConfigUtil.getOutputGraphDir() + "/Throughput.png");
		mft.parse();
		mft.writeOutput();
	}

	public static void main(String[] args) throws Exception {
		init();
		/*
		writeLineChart();
		writeFilteredMinMaxAvgChart();
		writeFilteredStackedBarChart();
		writeAllAtOnce();
		writeThroughPutChart();*/
		writeAggregateChart();
		writeAggregateChartWithThreshold();
	}
}
