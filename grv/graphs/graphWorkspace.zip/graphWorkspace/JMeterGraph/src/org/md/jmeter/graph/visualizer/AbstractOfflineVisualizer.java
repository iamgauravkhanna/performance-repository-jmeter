package org.md.jmeter.graph.visualizer;

import org.apache.jmeter.visualizers.gui.AbstractVisualizer;

/**
 * Abstract class to avoid having the methods below in each implementation
 * 
 * @author DS
 * 
 */
public abstract class AbstractOfflineVisualizer extends AbstractVisualizer
		implements OfflineVisualizer {

	private static final long serialVersionUID = 1L;

	/**
	 * we don't use this because these classes aren't meant to be cleared
	 */
	public void clearData() {
		// TODO Auto-generated method stub
	}

	/**
	 * haven't looked at what this does , doesn't seem to be needed
	 */
	public String getLabelResource() {
		// TODO Auto-generated method stub
		return null;
	}

}
