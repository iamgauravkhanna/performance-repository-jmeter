package org.md.jmeter.graph.visualizer;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.reporters.ResultCollectorHelper;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.util.JMeterUtils;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.CategoryTextAnnotation;
import org.jfree.chart.axis.CategoryAnchor;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.renderer.category.BarRenderer3D;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.statistics.Statistics;
import org.jfree.ui.Layer;
import org.jfree.ui.TextAnchor;
import org.md.jmeter.ConfigUtil;
import org.md.jmeter.XStreamJTLParser;

/**
 * Simulates the Aggregate Graph Visualizer in JMeter
 * 
 * @author DS
 * 
 */
public class AggregateChartVisualizer extends AbstractOfflineVisualizer {
	private static final long serialVersionUID = 1L;
	private final String prefixFileName;
	private final boolean showThreshold;
	private final double thresholdValue;
	private Map<String, List<Double>> map = new HashMap<String, List<Double>>();
	// hard coded this here, but probably needs to be specified on a per chart
	// basis
	// should have a way to specify the chart specific information like
	// dimensions, colors and labels
	// for now each class would have to be changed
	public static final int WIDTH = 640;
	public static final int HEIGHT = 480;

	/**
	 * @param fileName
	 *            , the generated image file
	 */
	public AggregateChartVisualizer(String prefixFileName) {
		this(prefixFileName,false,0);
	}
	public AggregateChartVisualizer(String prefixFileName, boolean showThreshold, double thresholdValue) {
		this.prefixFileName = prefixFileName;
		this.showThreshold = showThreshold;
		this.thresholdValue = thresholdValue;
	}

	/**
	 * add this sample
	 * 
	 * @param sampleResult
	 *            , the result from the log file
	 */
	public void add(SampleResult sampleResult) {
		String label = sampleResult.getSampleLabel();
		List<Double> s1 = map.get(label);
		if (s1 == null) {
			s1 = new ArrayList<Double>();
			map.put(label, s1);
		}
		long responseTime = sampleResult.getTime();
		s1.add(new Double(responseTime));
	}

	/**
	 * Writes the chart
	 * 
	 * @return , always returns null.
	 */
	public Object writeOutput() throws IOException {
		//Calculate various values
		DefaultCategoryDataset minCDS = new DefaultCategoryDataset();
		DefaultCategoryDataset maxCDS = new DefaultCategoryDataset();
		DefaultCategoryDataset avgCDS = new DefaultCategoryDataset();
		DefaultCategoryDataset ninetyCDS = new DefaultCategoryDataset();
		DefaultCategoryDataset medianCDS = new DefaultCategoryDataset();
		String xLabel = "Response Time";
		for (Map.Entry<String, List<Double>> entry : map.entrySet()) {
			List<Double> values = entry.getValue();
			String label = entry.getKey();
			Collections.sort(values);
			{
				Double min = values.get(0);
				Double max = values.get(values.size() -1);
				Double avg = Statistics.calculateMean(values);
				Double median = Statistics.calculateMedian(values);
				int pos = (int)Math.floor(values.size() * 0.9);
				Double ninetyPer = values.get(pos);
				minCDS.addValue(min, xLabel, label);
				maxCDS.addValue(max, xLabel, label);
				avgCDS.addValue(avg, xLabel, label);
				ninetyCDS.addValue(ninetyPer, xLabel, label);
				medianCDS.addValue(median, xLabel, label);
			}
			
		}
		writeChart("Minimum Response Time", minCDS, "-Min.png");
		writeChart("Maximum Response Time", maxCDS, "-Max.png");
		writeChart("Average Response Time", avgCDS, "-Avg.png");
		writeChart("Median Response Time", medianCDS, "-Median.png");
		writeChart("90% Response Time", ninetyCDS, "-90.png");
		return null;
	}

	private void writeChart(String name, CategoryDataset cd, String suffix) throws IOException{
		JFreeChart chart = createChart(name,cd);
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(prefixFileName + suffix);
			ChartUtilities.writeChartAsPNG(fos, chart, WIDTH, HEIGHT);
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
		
	}
	/**
	 * Get the JFreeChart chart object
	 * 
	 * @param dataset
	 *            , the data for the chart
	 * @return the jfreechart
	 */
	private JFreeChart createChart(String name, CategoryDataset cd) {
        JFreeChart jfreechart = ChartFactory.createBarChart3D(name, "Sample", "Response Time", cd, PlotOrientation.VERTICAL, true, true, false);
        CategoryPlot cp = (CategoryPlot)jfreechart.getPlot();
        if(showThreshold) {
        	  CustomBarRenderer3D custombarrenderer3d = new CustomBarRenderer3D(thresholdValue);
              cp.setRenderer(custombarrenderer3d);        	
              ValueMarker valuemarker = new ValueMarker(thresholdValue, new Color(0, 0, 255), new BasicStroke(1.0F), new Color(0, 0, 255), new BasicStroke(1.0F), 1.0F);
              cp.addRangeMarker(valuemarker, Layer.BACKGROUND);
              CategoryTextAnnotation cta = new CategoryTextAnnotation("Threshold", "Deepak", thresholdValue);
              cta.setCategoryAnchor(CategoryAnchor.START);
              cta.setFont(new Font("SansSerif", 0, 12));
              cta.setTextAnchor(TextAnchor.BOTTOM_LEFT);
              cp.addAnnotation(cta);
        }        
        CategoryItemRenderer cir = cp.getRenderer();
        cir.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
        cir.setBaseItemLabelsVisible(true);
        cir.setBasePositiveItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.OUTSIDE12, TextAnchor.BASELINE_LEFT));        	
        return jfreechart;		
	}
	
    static class CustomBarRenderer3D extends BarRenderer3D
    {
		private static final long serialVersionUID = 1L;
		private final double threshold; 
        public Paint getItemPaint(int i, int j)
        {
            CategoryDataset categorydataset = getPlot().getDataset();
            double d = categorydataset.getValue(i, j).doubleValue();
            if(d <= threshold)
                return Color.green;
            else
                return Color.red;
        }

        public CustomBarRenderer3D(double threshold)
        {
        	this.threshold = threshold;
        }
    }	

    public static void main(String [] args) throws Exception{
		JMeterUtils.setJMeterHome(ConfigUtil.getJMeterHome());
		JMeterUtils.getProperties(ConfigUtil.getJMeterProperties());    	
    	String jmeterResultFile = args[0]; 
    	String prefix = args[1];
    	String thresholdValue = args[2];
		File f = new File(jmeterResultFile);
		ResultCollector rc = new ResultCollector();
		AggregateChartVisualizer v = new AggregateChartVisualizer(prefix,true,new Double(thresholdValue));
		ResultCollectorHelper rch = new ResultCollectorHelper(rc, v);
		XStreamJTLParser p = new XStreamJTLParser(f, rch);
		p.parse();
		v.writeOutput();
    }
}
