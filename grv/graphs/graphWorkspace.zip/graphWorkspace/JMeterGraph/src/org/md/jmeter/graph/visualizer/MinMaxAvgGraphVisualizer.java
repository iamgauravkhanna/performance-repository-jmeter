package org.md.jmeter.graph.visualizer;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.protocol.http.sampler.HTTPSampleResult;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.RectangleInsets;

/**
 * Draws response time, min time, max time, avg time. Using this graph for
 * multiple samples makes the graph difficult to read. The LabelFilterVisualizer
 * can help filter out the labels we want Memory usage is dependent on number of
 * samples
 * 
 * @author DS
 * 
 */
public class MinMaxAvgGraphVisualizer extends AbstractOfflineVisualizer {
	private static final long serialVersionUID = 1L;
	private final String fileName;
	private Map<String, TimeSeries> map = new HashMap<String, TimeSeries>();
	private Date minDate = null;
	private Date maxDate = null;
	private Map<String, Long> maxTimeMap = new HashMap<String, Long>();
	private Map<String, Long> minTimeMap = new HashMap<String, Long>();
	private Map<String, Long> sampleCountMap = new HashMap<String, Long>();
	private Map<String, Long> totalElapsedMap = new HashMap<String, Long>();
	private static final int WIDTH = 640;
	private static final int HEIGHT = 480;

	public MinMaxAvgGraphVisualizer(String fileName) {
		this.fileName = fileName;
	}

	public void add(SampleResult sampleResult) {
		if (sampleResult instanceof HTTPSampleResult) {
			String label = sampleResult.getSampleLabel();
			TimeSeries s1 = map.get(label);
			if (s1 == null) {
				s1 = new TimeSeries(label);
				map.put(label, s1);
			}
			long responseTime = sampleResult.getTime();
			Date d = new Date(sampleResult.getStartTime());
			if (minDate == null || d.before(minDate)) {
				minDate = d;
			}
			if (maxDate == null || d.after(maxDate)) {
				maxDate = d;
			}
			Long maxTime = maxTimeMap.get(label);
			if (maxTime == null || responseTime > maxTime) {
				maxTimeMap.put(label, responseTime);
			}
			Long minTime = minTimeMap.get(label);
			if (minTime == null || responseTime < minTime) {
				minTimeMap.put(label, responseTime);
			}
			Long count = sampleCountMap.get(label);
			if (count == null) {
				sampleCountMap.put(label, 1L);
			} else {
				sampleCountMap.put(label, count + 1);
			}
			Long totalTime = totalElapsedMap.get(label);
			if (totalTime == null) {
				totalElapsedMap.put(label, responseTime);
			} else {
				totalElapsedMap.put(label, totalTime + responseTime);
			}
			s1.addOrUpdate(new Millisecond(d), responseTime);
		}
	}

	public Object writeOutput() throws IOException {
		TimeSeriesCollection dataset = new TimeSeriesCollection();
		for (Map.Entry<String, TimeSeries> entry : map.entrySet()) {
			dataset.addSeries(entry.getValue());
			// also add the remaining graphs that we want
			String label = entry.getKey();
			{
				Long minTime = minTimeMap.get(label);
				TimeSeries s1 = new TimeSeries(label + " Min");
				s1.addOrUpdate(new Millisecond(minDate), minTime);
				s1.addOrUpdate(new Millisecond(maxDate), minTime);
				dataset.addSeries(s1);
			}
			{
				Long maxTime = maxTimeMap.get(label);
				TimeSeries s1 = new TimeSeries(label + " Max");
				s1.addOrUpdate(new Millisecond(minDate), maxTime);
				s1.addOrUpdate(new Millisecond(maxDate), maxTime);
				dataset.addSeries(s1);
			}
			{
				Long totalTime = totalElapsedMap.get(label);
				Long sampleCount = sampleCountMap.get(label);
				Long avg = totalTime / sampleCount;
				TimeSeries s1 = new TimeSeries(label + " Avg");
				s1.addOrUpdate(new Millisecond(minDate), avg);
				s1.addOrUpdate(new Millisecond(maxDate), avg);
				dataset.addSeries(s1);
			}

		}

		JFreeChart chart = createChart(dataset);
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(fileName);
			ChartUtilities.writeChartAsPNG(fos, chart, WIDTH, HEIGHT);
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
		return null;
	}

	/**
	 * Gets the jfreechart object
	 * 
	 * @param dataset
	 *            , data
	 * @return
	 */
	private static JFreeChart createChart(XYDataset dataset) {

		JFreeChart chart = ChartFactory.createTimeSeriesChart("Response Chart", // title
				"Date", // x-axis label
				"Time(ms)", // y-axis label
				dataset, // data
				true, // create legend?
				true, // generate tooltips?
				false // generate URLs?
				);

		chart.setBackgroundPaint(Color.white);

		XYPlot plot = (XYPlot) chart.getPlot();
		plot.setBackgroundPaint(Color.lightGray);
		plot.setDomainGridlinePaint(Color.white);
		plot.setRangeGridlinePaint(Color.white);
		plot.setAxisOffset(new RectangleInsets(5.0, 5.0, 5.0, 5.0));
		plot.setDomainCrosshairVisible(true);
		plot.setRangeCrosshairVisible(true);

		XYItemRenderer r = plot.getRenderer();
		if (r instanceof XYLineAndShapeRenderer) {
			XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) r;
			renderer.setBaseShapesVisible(true);
			renderer.setBaseShapesFilled(true);
			renderer.setDrawSeriesLineAsPath(true);
		}

		DateAxis axis = (DateAxis) plot.getDomainAxis();
		axis.setDateFormatOverride(new SimpleDateFormat("dd-MMM-yyyy HH:mm"));

		return chart;

	}

}
