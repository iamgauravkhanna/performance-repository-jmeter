package org.md.jmeter.graph.visualizer;

import java.awt.Color;
import java.awt.GradientPaint;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.jmeter.samplers.SampleResult;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.DateTickMarkPosition;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StackedXYBarRenderer;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeTableXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.ui.GradientPaintTransformType;
import org.jfree.ui.StandardGradientPaintTransformer;

/**
 * Generates a stacked bar chart of response times X axis is the start time of
 * the sample Y axis is a stacked bar of time. The stacks are the latency and
 * the rest of the response time Doesnt look too well with multiple labels, the
 * sample uses a LabelFilterVisualizer to only generate this for a single sample
 * Memory usage is dependent on number of samples
 * 
 * @author DS
 * 
 */
public class StackedBarChartVisualizer extends AbstractOfflineVisualizer {
	private static final long serialVersionUID = 1L;
	private final String fileName;
	private TimeTableXYDataset dataset = new TimeTableXYDataset();
	private static final int WIDTH = 800;
	private static final int HEIGHT = 600;

	public StackedBarChartVisualizer(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @param sampleResult
	 */
	public void add(SampleResult sampleResult) {
		long responseTime = sampleResult.getTime();
		long latency = sampleResult.getLatency();
		Date d = new Date(sampleResult.getStartTime());
		dataset.add(new Second(d), latency, "latency");
		dataset.add(new Second(d), responseTime - latency, "response time");
	}

	/**
	 * @return always returns null
	 */
	public Object writeOutput() throws IOException {
		JFreeChart chart = createChart(dataset);
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(fileName);
			ChartUtilities.writeChartAsPNG(fos, chart, WIDTH, HEIGHT);
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
		return null;
	}

	/**
	 * Get the jfreechart object
	 * 
	 * @param dataset
	 * @return
	 */
	private static JFreeChart createChart(TableXYDataset dataset) {
		DateAxis axis = new DateAxis("Time");
		axis.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
		axis.setLowerMargin(0.01D);
		axis.setUpperMargin(0.01D);
		axis
				.setDateFormatOverride(new SimpleDateFormat(
						"dd-MMM-yyyy HH:mm:ss"));
		NumberAxis numberAxis = new NumberAxis("Response Time(ms)");
		StackedXYBarRenderer renderer = new StackedXYBarRenderer();
		renderer.setDrawBarOutline(false);
		XYPlot xyplot = new XYPlot(dataset, axis, numberAxis, renderer);
		JFreeChart chart = new JFreeChart("Response Plot", xyplot);
		chart.setBackgroundPaint(Color.white);
		ChartUtilities.applyCurrentTheme(chart);
		GradientPaint gradientpaint = new GradientPaint(0.0F, 0.0F, new Color(
				64, 0, 0), 0.0F, 0.0F, Color.red);
		GradientPaint gradientpaint1 = new GradientPaint(0.0F, 0.0F, new Color(
				0, 64, 0), 0.0F, 0.0F, Color.green);
		renderer.setSeriesPaint(0, gradientpaint);
		renderer.setSeriesPaint(1, gradientpaint1);
		renderer
				.setGradientPaintTransformer(new StandardGradientPaintTransformer(
						GradientPaintTransformType.HORIZONTAL));
		return chart;
	}

}
