package org.md.jmeter.ant;

import java.io.File;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.md.jmeter.GraphClient;

public class AggregateGraphTask extends Task {
	private String outputDir;
	private String outputFilePrefix;
	private Boolean showThreshold = Boolean.TRUE;
	private Double threshold = 500D;
	private String jmeterResultFile;
	private String jmeterHome;
	
	public String getJmeterHome() {
		return jmeterHome;
	}

	public void setJmeterHome(String jmeterHome) {
		this.jmeterHome = jmeterHome;
	}

	public String getJmeterResultFile() {
		return jmeterResultFile;
	}

	public void setJmeterResultFile(String jmeterResultFile) {
		this.jmeterResultFile = jmeterResultFile;
	}

	public String getOutputDir() {
		return outputDir;
	}

	public void setOutputDir(String outputDir) {
		this.outputDir = outputDir;
	}

	public String getOutputFilePrefix() {
		return outputFilePrefix;
	}

	public void setOutputFilePrefix(String outputFilePrefix) {
		this.outputFilePrefix = outputFilePrefix;
	}

	public Boolean getShowThreshold() {
		return showThreshold;
	}

	public void setShowThreshold(Boolean showThreshold) {
		this.showThreshold = showThreshold;
	}

	public Double getThreshold() {
		return threshold;
	}

	public void setThreshold(Double threshold) {
		this.threshold = threshold;
	}

	@Override
	public void execute() throws BuildException {
		try {
			GraphClient.init(jmeterHome);
			String outputPrefix = outputDir +  File.separator + outputFilePrefix;
			if(Boolean.TRUE.equals(showThreshold))  {
				GraphClient.writeAggregateChartWithThreshold(jmeterResultFile, outputPrefix, showThreshold, threshold);
			} else {
				GraphClient.writeAggregateChart(jmeterResultFile, outputPrefix)	;
			}
		} catch(Exception e) {
			throw new BuildException(e);
		}
	}

}
