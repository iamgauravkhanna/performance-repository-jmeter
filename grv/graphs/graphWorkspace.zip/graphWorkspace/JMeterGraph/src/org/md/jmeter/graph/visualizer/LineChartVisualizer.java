package org.md.jmeter.graph.visualizer;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.jmeter.samplers.SampleResult;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.RectangleInsets;

/**
 * Draw a line chart. X Axis is the start time of the sample Y axis is the
 * response time in milliseconds Memory usage would grow with the number of
 * items
 * 
 * @author DS
 * 
 */
public class LineChartVisualizer extends AbstractOfflineVisualizer {
	private static final long serialVersionUID = 1L;
	private final String fileName;
	private Map<String, TimeSeries> map = new HashMap<String, TimeSeries>();
	// hardcoded this here, but probably needs to be specified on a per chart
	// basis
	// should have a way to specify the chart specific information like
	// dimensions, colors and labels
	// for now each class would have to be changed
	public static final int WIDTH = 640;
	public static final int HEIGHT = 480;

	/**
	 * @param fileName
	 *            , the generated image file
	 */
	public LineChartVisualizer(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * add this sample
	 * 
	 * @param sampleResult
	 *            , the result from the log file
	 */
	public void add(SampleResult sampleResult) {
		String label = sampleResult.getSampleLabel();
		TimeSeries s1 = map.get(label);
		if (s1 == null) {
			s1 = new TimeSeries(label);
			map.put(label, s1);
		}
		long responseTime = sampleResult.getTime();
		Date d = new Date(sampleResult.getStartTime());
		s1.addOrUpdate(new Millisecond(d), responseTime);
	}

	/**
	 * Writes the chart
	 * 
	 * @return , always returns null.
	 */
	public Object writeOutput() throws IOException {
		TimeSeriesCollection dataset = new TimeSeriesCollection();
		for (Map.Entry<String, TimeSeries> entry : map.entrySet()) {
			dataset.addSeries(entry.getValue());
		}
		JFreeChart chart = createChart(dataset);
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(fileName);
			ChartUtilities.writeChartAsPNG(fos, chart, WIDTH, HEIGHT);
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
		return null;
	}

	/**
	 * Get the JFreeChart chart object
	 * 
	 * @param dataset
	 *            , the data for the chart
	 * @return the jfreechart
	 */
	private static JFreeChart createChart(XYDataset dataset) {
		JFreeChart chart = ChartFactory.createTimeSeriesChart("Response Chart", // title
				"Date", // x-axis label
				"Time(ms)", // y-axis label
				dataset, // data
				true, // create legend?
				true, // generate tooltips?
				false // generate URLs?
				);

		chart.setBackgroundPaint(Color.white);
		XYPlot plot = (XYPlot) chart.getPlot();
		plot.setBackgroundPaint(Color.lightGray);
		plot.setDomainGridlinePaint(Color.white);
		plot.setRangeGridlinePaint(Color.white);
		plot.setAxisOffset(new RectangleInsets(5.0, 5.0, 5.0, 5.0));
		plot.setDomainCrosshairVisible(true);
		plot.setRangeCrosshairVisible(true);
		XYItemRenderer r = plot.getRenderer();
		if (r instanceof XYLineAndShapeRenderer) {
			XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) r;
			renderer.setBaseShapesVisible(true);
			renderer.setBaseShapesFilled(true);
			renderer.setDrawSeriesLineAsPath(true);
		}
		DateAxis axis = (DateAxis) plot.getDomainAxis();
		axis.setDateFormatOverride(new SimpleDateFormat("dd-MMM-yyyy HH:mm"));
		return chart;
	}

}
