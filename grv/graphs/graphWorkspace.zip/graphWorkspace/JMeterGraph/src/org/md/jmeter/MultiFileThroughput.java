package org.md.jmeter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.reporters.ResultCollectorHelper;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.md.jmeter.graph.visualizer.AbstractOfflineVisualizer;
import org.md.jmeter.graph.visualizer.Throughput;
import org.md.jmeter.graph.visualizer.TotalThroughputVisualizer;

/**
 * Uses multiple result files to get a throughput graph X axis is number of
 * threads Y axis is throughput in requests per minute
 * 
 * @author DS
 * 
 */
public class MultiFileThroughput {
	private final List<String> files;
	private final String fileName;
	// we have one for each result file
	private List<AbstractOfflineVisualizer> visualizers = new ArrayList<AbstractOfflineVisualizer>();
	private static final int WIDTH = 640;
	private static final int HEIGHT = 480;

	/**
	 * 
	 * @param files
	 *            , each result file
	 * @param fileName
	 *            , the output image file
	 */
	public MultiFileThroughput(List<String> files, String fileName) {
		this.files = files;
		this.fileName = fileName;
	}

	/**
	 * parses each file
	 * 
	 * @throws Exception
	 */
	public void parse() throws Exception {
		// One day we might multithread this
		for (String file : files) {
			ResultCollector rc = new ResultCollector();
			TotalThroughputVisualizer ttv = new TotalThroughputVisualizer();
			visualizers.add(ttv);
			ResultCollectorHelper rch = new ResultCollectorHelper(rc, ttv);
			XStreamJTLParser p = new XStreamJTLParser(new File(file), rch);
			p.parse();
		}
	}

	/**
	 * Gets the resulting throughput from each file and combines them
	 * 
	 * @return always returns null
	 * @throws IOException
	 */
	public Object writeOutput() throws IOException {
		XYSeries xyseries = new XYSeries("throughput");
		for (AbstractOfflineVisualizer visualizer : visualizers) {
			Throughput throughput = (Throughput) visualizer.writeOutput();
			xyseries.add(throughput.getThreadCount(), throughput
					.getThroughput());
		}
		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(xyseries);
		JFreeChart chart = createChart(dataset);
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(fileName);
			ChartUtilities.writeChartAsPNG(fos, chart, WIDTH, HEIGHT);
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
		return null;
	}

	/**
	 * @param dataset
	 *            , the data for the chart
	 * @return the jfreechart object
	 */
	private static JFreeChart createChart(XYDataset dataset) {
		JFreeChart jfreechart = ChartFactory.createXYLineChart(
				"Throughput chart", "Number of threads",
				"Throughput(Requests/min)", dataset, PlotOrientation.VERTICAL,
				true, true, false);
		XYPlot xyplot = (XYPlot) jfreechart.getPlot();
		xyplot.setDomainPannable(true);
		xyplot.setRangePannable(true);
		XYLineAndShapeRenderer xylineandshaperenderer = (XYLineAndShapeRenderer) xyplot
				.getRenderer();
		xylineandshaperenderer.setBaseShapesVisible(true);
		xylineandshaperenderer.setBaseShapesFilled(true);
		NumberAxis numberaxis = (NumberAxis) xyplot.getRangeAxis();
		numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
		return jfreechart;
	}
}
