package org.md.jmeter.graph.visualizer;

import java.io.IOException;

import org.apache.jmeter.samplers.SampleResult;

/**
 * Useful to filter out only HTTPSampleResult (so that things like beanshell
 * samplers dont show up in the count)
 * 
 * @author DS
 * 
 */
public class ClassGraphFilterVisualizer extends AbstractOfflineVisualizer {
	private static final long serialVersionUID = 1L;
	private final AbstractOfflineVisualizer visualizer;
	@SuppressWarnings("unchecked")
	private final Class clazz;
	private final boolean pass;

	@SuppressWarnings("unchecked")
	public ClassGraphFilterVisualizer(Class clazz,
			AbstractOfflineVisualizer visualizer) {
		this(clazz, visualizer, true);
	}

	@SuppressWarnings("unchecked")
	public ClassGraphFilterVisualizer(Class clazz,
			AbstractOfflineVisualizer visualizer, boolean pass) {
		this.clazz = clazz;
		this.visualizer = visualizer;
		this.pass = pass;

	}

	/**
	 * delegates to the decorated visualizer
	 */
	public Object writeOutput() throws IOException {
		return visualizer.writeOutput();
	}

	/**
	 * decorates the visualizer by filtering out classes that match (or dont
	 * match) the specified class
	 */
	public void add(SampleResult sampleResult) {
		boolean allow = sampleResult.getClass().equals(clazz);
		if (!pass) {
			allow = !allow;
		}
		if (allow) {
			visualizer.add(sampleResult);
		}
	}

}
