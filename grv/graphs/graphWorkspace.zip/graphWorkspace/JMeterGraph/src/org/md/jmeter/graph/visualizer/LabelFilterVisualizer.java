package org.md.jmeter.graph.visualizer;

import java.io.IOException;
import java.util.List;

import org.apache.jmeter.samplers.SampleResult;

/**
 * Filters based on the sample's label
 * 
 * @author DS
 * 
 */
public class LabelFilterVisualizer extends AbstractOfflineVisualizer {
	private static final long serialVersionUID = 1L;
	private final List<String> labels;
	private final AbstractOfflineVisualizer visualizer;
	private final boolean pass;

	/**
	 * only passes the labels specified to the decorated visualizer
	 * 
	 * @param labels
	 * @param visualizer
	 */
	public LabelFilterVisualizer(List<String> labels,
			AbstractOfflineVisualizer visualizer) {
		this(labels, visualizer, true);
	}

	/**
	 * 
	 * @param labels
	 *            , the labels to check
	 * @param visualizer
	 *            , the decorated visualizer
	 * @param pass
	 *            , true means the sample is passed if it is present in the list
	 *            of labels, false means the sample is not passed if it is in
	 *            the list of labels
	 */
	public LabelFilterVisualizer(List<String> labels,
			AbstractOfflineVisualizer visualizer, boolean pass) {
		this.labels = labels;
		this.visualizer = visualizer;
		this.pass = pass;
	}

	/**
	 * delegates to the decorated visualizer
	 * 
	 * @return whatever the decorated visualizer returns
	 */
	public Object writeOutput() throws IOException {
		return visualizer.writeOutput();
	}

	/**
	 * decorates the visualizer by filtering out labels
	 */
	public void add(SampleResult sampleResult) {
		boolean allow = labels.contains(sampleResult.getSampleLabel());
		if (!pass) {
			allow = !allow;
		}
		if (allow) {
			visualizer.add(sampleResult);
		}
	}

}
