package org.md.jmeter.graph.visualizer;

/**
 * Simple value class containing throughput and threadcounts
 * 
 * @author DS
 * 
 */
public class Throughput {
	private final int threadCount;
	private final double throughput;

	public Throughput(int threadCount, double throughput) {
		this.threadCount = threadCount;
		this.throughput = throughput;
	}

	public int getThreadCount() {
		return threadCount;
	}

	public double getThroughput() {
		return throughput;
	}

	@Override
	public String toString() {
		return "Throughput [threadCount=" + threadCount + ", throughput="
				+ throughput + "]";
	}

}
