package org.md.jmeter.graph.visualizer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.jmeter.samplers.SampleResult;

/**
 * Composite to run multiple operations. Should be multithreaded, but isn't, its
 * offline so if it takes too much time , so be it.
 * 
 * @author DS
 */
public class CompositeVisualizer extends AbstractOfflineVisualizer {
	private static final long serialVersionUID = 1L;
	private final List<OfflineVisualizer> visualizers;

	public CompositeVisualizer(List<OfflineVisualizer> visualizers) {
		this.visualizers = visualizers;
	}

	/**
	 * adds the sample to each of the composed visualizers
	 */
	public void add(SampleResult sampleResult) {
		for (OfflineVisualizer visualizer : visualizers) {
			visualizer.add(sampleResult);
		}

	}

	/**
	 * @return a List of each result from the composed visualizer
	 */
	public Object writeOutput() throws IOException {
		List<Object> result = new ArrayList<Object>();
		for (OfflineVisualizer visualizer : visualizers) {
			result.add(visualizer.writeOutput());
		}
		return result;
	}
}
